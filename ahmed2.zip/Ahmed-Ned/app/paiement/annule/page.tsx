'use client'

import { Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'

function PaymentCancelledContent() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get('order')

  return (
    <main className="flex flex-col items-center justify-center min-h-screen text-center px-6 py-24 bg-white dark:bg-gray-950">
      <div className="max-w-lg">
        <div className="w-20 h-20 bg-orange-50 dark:bg-orange-900/20 rounded-full flex items-center justify-center mx-auto mb-8">
          <span className="text-4xl">⚠️</span>
        </div>
        <h1 className="font-display text-4xl text-navy dark:text-white font-bold mb-4">
          Paiement annulé
        </h1>
        <p className="text-lg text-muted dark:text-gray-400 leading-relaxed mb-8">
          Le paiement a été annulé ou une erreur s&apos;est produite.
          Aucun montant n&apos;a été débité de votre compte.
        </p>

        {orderId && (
          <div className="bg-cream dark:bg-gray-900 rounded-2xl p-6 mb-8">
            <p className="text-xs font-semibold text-charcoal/50 dark:text-gray-500 uppercase tracking-widest mb-2">
              Référence
            </p>
            <p className="text-lg font-mono text-navy dark:text-white">{orderId}</p>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/tarifs"
            className="btn-primary bg-navy text-white hover:bg-navy/90 dark:bg-gold dark:text-navy dark:hover:bg-gold-light"
          >
            Réessayer le paiement
          </Link>
          <Link
            href="/prendre-rendez-vous"
            className="btn-outline border-navy text-navy hover:bg-navy/5 dark:border-gold dark:text-gold dark:hover:bg-gold/10"
          >
            Nous contacter
          </Link>
        </div>

        <p className="mt-8 text-sm text-muted dark:text-gray-400">
          Besoin d&apos;aide ?{' '}
          <a
            href="mailto:nedjar.objectif.reussite@gmail.com"
            className="text-navy dark:text-gold font-medium hover:underline"
          >
            Contactez-nous
          </a>
        </p>
      </div>
    </main>
  )
}

export default function PaymentCancelledPage() {
  return (
    <>
      <Header />
      <Suspense
        fallback={
          <main className="flex flex-col items-center justify-center min-h-screen text-center px-6 py-24 bg-white dark:bg-gray-950">
            <div className="max-w-lg">
              <div className="w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse" />
              <h1 className="font-display text-4xl text-navy dark:text-white font-bold mb-4">
                Chargement...
              </h1>
            </div>
          </main>
        }
      >
        <PaymentCancelledContent />
      </Suspense>
      <Footer />
    </>
  )
}
