'use client'

import { Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'

function PaymentStatusContent() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get('order')

  return (
    <main className="flex flex-col items-center justify-center min-h-screen text-center px-6 py-24 bg-white dark:bg-gray-950">
      <div className="max-w-lg">
        <div className="w-20 h-20 bg-green-50 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-8">
          <span className="text-4xl">✅</span>
        </div>
        <h1 className="font-display text-4xl text-navy dark:text-white font-bold mb-4">
          Paiement confirmé !
        </h1>
        <p className="text-lg text-muted dark:text-gray-400 leading-relaxed mb-8">
          Merci pour votre règlement. Votre commande a été traitée avec succès.
          M. Nedjar vous contactera sous 24h pour confirmer le créneau et les modalités de la séance.
        </p>

        {orderId && (
          <div className="bg-cream dark:bg-gray-900 rounded-2xl p-6 mb-8">
            <p className="text-xs font-semibold text-charcoal/50 dark:text-gray-500 uppercase tracking-widest mb-2">
              Numéro de commande
            </p>
            <p className="text-lg font-mono text-navy dark:text-white">{orderId}</p>
          </div>
        )}

        <div className="bg-gray-50 dark:bg-gray-900 rounded-2xl p-6 mb-8 text-sm text-muted dark:text-gray-400">
          <p>Une confirmation vous sera envoyée par email.</p>
          <p className="mt-1">
            En cas de question :{' '}
            <a
              href="mailto:nedjar.objectif.reussite@gmail.com"
              className="text-navy dark:text-gold font-medium hover:underline"
            >
              nedjar.objectif.reussite@gmail.com
            </a>
          </p>
        </div>

        <Link
          href="/"
          className="btn-primary bg-navy text-white hover:bg-navy/90 dark:bg-gold dark:text-navy dark:hover:bg-gold-light"
        >
          Retour à l&apos;accueil
        </Link>
      </div>
    </main>
  )
}

export default function PaymentStatusPage() {
  return (
    <>
      <Header />
      <Suspense
        fallback={
          <main className="flex flex-col items-center justify-center min-h-screen text-center px-6 py-24 bg-white dark:bg-gray-950">
            <div className="max-w-lg">
              <div className="w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse">
                <span className="text-4xl">⏳</span>
              </div>
              <h1 className="font-display text-4xl text-navy dark:text-white font-bold mb-4">
                Chargement...
              </h1>
              <p className="text-lg text-muted dark:text-gray-400 leading-relaxed">
                Veuillez patienter pendant que nous vérifions votre paiement.
              </p>
            </div>
          </main>
        }
      >
        <PaymentStatusContent />
      </Suspense>
      <Footer />
    </>
  )
}
