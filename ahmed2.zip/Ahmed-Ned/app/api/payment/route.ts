import { createMollieClient, PaymentMethod } from '@mollie/api-client'
import { NextRequest, NextResponse } from 'next/server'

const mollieClient = (() => {
  const apiKey = process.env.MOLLIE_API_KEY
  if (!apiKey) {
    console.error('MOLLIE_API_KEY not configured')
    return null
  }
  return createMollieClient({ apiKey })
})()

// Supported payment methods
const PAYMENT_METHODS = [
  PaymentMethod.creditcard,
  PaymentMethod.applepay,
  PaymentMethod.googlepay,
  PaymentMethod.ideal,
  PaymentMethod.bancontact,
  PaymentMethod.sofort,
  PaymentMethod.eps,
  PaymentMethod.giropay,
  PaymentMethod.paypal,
]

export async function POST(req: NextRequest) {
  try {
    // Check if Mollie client is initialized
    if (!mollieClient) {
      return NextResponse.json(
        { error: 'Configuration de paiement manquante. Contactez l\'administrateur.' },
        { status: 503 }
      )
    }

    // Parse and validate request body
    let body: { amount?: string; description?: string; customerEmail?: string; metadata?: Record<string, string> }
    try {
      body = await req.json()
    } catch {
      return NextResponse.json({ error: 'Corps de la requête invalide' }, { status: 400 })
    }

    const { amount, description, customerEmail, metadata = {} } = body

    // Validate required fields
    if (!amount || !description) {
      return NextResponse.json(
        { error: 'Paramètres manquants: amount et description sont requis' },
        { status: 400 }
      )
    }

    // Validate amount format (should be a valid decimal string)
    if (!/^\d+(\.\d{1,2})?$/.test(amount)) {
      return NextResponse.json(
        { error: 'Format du montant invalide' },
        { status: 400 }
      )
    }

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || process.env.NEXT_PUBLIC_SITE_URL || 'https://monpetitgenie.io'

    // Create unique order ID for tracking
    const orderId = `ORDER-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`

    // Create payment with Mollie
    const payment = await mollieClient.payments.create({
      amount: {
        currency: 'EUR',
        value: amount.includes('.') ? amount : `${amount}.00`
      },
      description: description.substring(0, 255), // Mollie limit
      redirectUrl: `${baseUrl}/paiement/statut?order=${orderId}`,
      webhookUrl: `${baseUrl}/api/webhook`,
      method: PAYMENT_METHODS,
      metadata: {
        orderId,
        customerEmail: customerEmail || '',
        ...metadata
      },
      // Enable test mode if key starts with test_
      testmode: process.env.MOLLIE_API_KEY?.startsWith('test_') ?? false,
    })

    // Extract checkout URL
    const checkoutUrl = payment.getCheckoutUrl()

    if (!checkoutUrl) {
      return NextResponse.json(
        { error: 'Erreur lors de la création du paiement - URL de paiement non disponible' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      checkoutUrl,
      paymentId: payment.id,
      orderId,
      expiresAt: payment.expiresAt,
    })
  } catch (error) {
    console.error('Erreur Mollie payment:', error)

    // Handle specific Mollie errors
    if (error instanceof Error) {
      if (error.message.includes('Unauthorized')) {
        return NextResponse.json(
          { error: 'Erreur d\'authentification Mollie. Vérifiez la configuration API.' },
          { status: 401 }
        )
      }
      if (error.message.includes('amount')) {
        return NextResponse.json(
          { error: 'Montant invalide' },
          { status: 400 }
        )
      }
    }

    return NextResponse.json(
      { error: 'Erreur lors de la création du paiement. Veuillez réessayer.' },
      { status: 500 }
    )
  }
}
