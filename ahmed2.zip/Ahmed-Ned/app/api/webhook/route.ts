import { createMollieClient } from '@mollie/api-client'
import { NextRequest, NextResponse } from 'next/server'

const mollieClient = (() => {
  const apiKey = process.env.MOLLIE_API_KEY
  if (!apiKey) {
    console.error('MOLLIE_API_KEY not configured for webhook')
    return null
  }
  return createMollieClient({ apiKey })
})()

export async function POST(req: NextRequest) {
  try {
    // Check if Mollie client is initialized
    if (!mollieClient) {
      console.error('Webhook: Mollie client not initialized')
      return NextResponse.json({ error: 'Configuration manquante' }, { status: 503 })
    }

    // Parse webhook body (Mollie sends form data)
    let body: FormData
    let paymentId: string | null

    try {
      body = await req.formData()
      paymentId = body.get('id') as string
    } catch {
      console.error('Webhook: Failed to parse form data')
      return NextResponse.json({ error: 'Invalid request format' }, { status: 400 })
    }

    if (!paymentId) {
      console.error('Webhook: Missing payment ID')
      return NextResponse.json({ error: 'ID manquant' }, { status: 400 })
    }

    // Fetch payment details from Mollie
    const payment = await mollieClient.payments.get(paymentId)

    // Handle different payment statuses
    switch (payment.status) {
      case 'paid':
        console.log('✅ Paiement confirmé:', {
          id: payment.id,
          amount: payment.amount?.value,
          currency: payment.amount?.currency,
          description: payment.description,
          method: payment.method,
          orderId: payment.metadata?.orderId,
          customerEmail: payment.metadata?.customerEmail,
          paidAt: payment.paidAt,
        })
        // TODO: Send confirmation email, update database, etc.
        break

      case 'pending':
        console.log('⏳ Paiement en attente:', payment.id)
        break

      case 'canceled':
        console.log('❌ Paiement annulé:', payment.id)
        break

      case 'failed':
        console.log('💥 Paiement échoué:', payment.id)
        break

      case 'expired':
        console.log('⌛ Paiement expiré:', payment.id)
        break

      default:
        console.log('ℹ️ Statut de paiement:', payment.status, payment.id)
    }

    // Always return 200 to acknowledge receipt
    return NextResponse.json({ received: true, status: payment.status })
  } catch (error) {
    console.error('Erreur webhook Mollie:', error)
    // Return 200 even on error to prevent Mollie from retrying
    return NextResponse.json({ received: true, error: 'Processing error' })
  }
}
