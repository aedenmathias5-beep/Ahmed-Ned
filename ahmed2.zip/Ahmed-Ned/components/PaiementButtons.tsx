'use client'

import { useState } from 'react'

const offres = [
  {
    label: '🎓 Séance individuelle',
    subtitle: '1h de cours particulier',
    amount: '60.00',
    description: 'Cours particulier 1h — Mathématiques',
  },
  {
    label: '⚡ Stage vacances',
    subtitle: 'Journée intensive',
    amount: '150.00',
    description: 'Stage intensif vacances scolaires — Mathématiques',
  },
  {
    label: '🎯 Préparation examen',
    subtitle: 'Session Brevet / Bac',
    amount: '120.00',
    description: 'Préparation examen Brevet / Baccalauréat — Mathématiques',
  },
]

export default function PaiementButtons() {
  const [loading, setLoading] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [email, setEmail] = useState('')
  const [showEmail, setShowEmail] = useState(false)
  const [selectedOffer, setSelectedOffer] = useState<{ amount: string; description: string; label: string } | null>(null)

  const handleSelectOffer = (offer: typeof offres[0]) => {
    setSelectedOffer(offer)
    setShowEmail(true)
    setError(null)
  }

  const handlePayment = async () => {
    if (!selectedOffer) return

    if (!email || !email.includes('@')) {
      setError('Veuillez entrer une adresse email valide')
      return
    }

    setLoading(selectedOffer.amount)
    setError(null)

    try {
      const res = await fetch('/api/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: selectedOffer.amount,
          description: selectedOffer.description,
          customerEmail: email,
          metadata: {
            offerLabel: selectedOffer.label,
          }
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error ?? 'Erreur lors de la création du paiement')
      }

      if (!data.checkoutUrl) {
        throw new Error('URL de paiement non disponible')
      }

      window.location.href = data.checkoutUrl
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue. Veuillez réessayer ou nous contacter directement.')
      setLoading(null)
    }
  }

  if (showEmail && selectedOffer) {
    return (
      <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-6">
        <button
          onClick={() => setShowEmail(false)}
          className="text-sm text-muted hover:text-navy dark:hover:text-gold transition-colors mb-4"
        >
          ← Retour aux offres
        </button>

        <div className="mb-6 p-4 bg-cream dark:bg-gray-800 rounded-xl">
          <p className="text-sm text-muted dark:text-gray-400 mb-1">Offre sélectionnée</p>
          <p className="font-bold text-navy dark:text-white">{selectedOffer.label}</p>
          <p className="text-2xl font-bold text-gold">{selectedOffer.amount.replace('.00', '')}€</p>
        </div>

        <div className="space-y-4">
          <div>
            <label htmlFor="payment-email" className="block text-sm font-medium text-navy dark:text-white mb-2">
              Adresse email pour la confirmation
            </label>
            <input
              type="email"
              id="payment-email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="votre@email.com"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-navy dark:text-white focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent transition-all"
              disabled={loading !== null}
            />
            <p className="text-xs text-muted mt-2">
              La confirmation de paiement sera envoyée à cette adresse.
            </p>
          </div>

          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800 rounded-xl">
              <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
            </div>
          )}

          <button
            onClick={handlePayment}
            disabled={loading !== null}
            className="w-full btn-primary justify-center disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Redirection vers Mollie...
              </>
            ) : (
              `Payer ${selectedOffer.amount.replace('.00', '')}€`
            )}
          </button>
        </div>

        <p className="text-xs text-muted text-center mt-4">
          Paiement sécurisé par Mollie · CB, Apple Pay, Google Pay, iDEAL et plus
        </p>
      </div>
    )
  }

  return (
    <div>
      <div className="grid sm:grid-cols-3 gap-4 mb-4">
        {offres.map((o) => (
          <button
            key={o.amount}
            onClick={() => handleSelectOffer(o)}
            disabled={loading !== null}
            className="group relative bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-6 text-left hover:border-gold/50 hover:shadow-lg transition-all duration-300 card-premium disabled:opacity-60 disabled:cursor-not-allowed"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-navy via-gold to-navy opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-t-2xl" />
            <p className="text-base font-bold text-navy dark:text-white mb-1">{o.label}</p>
            <p className="text-xs text-muted dark:text-gray-400 mb-3">{o.subtitle}</p>
            <p className="text-2xl font-bold text-gold">{o.amount.replace('.00', '')}€</p>
            <p className="mt-4 text-xs font-semibold text-navy/60 dark:text-gray-400 group-hover:text-navy dark:group-hover:text-gold transition-colors">
              Sélectionner →
            </p>
          </button>
        ))}
      </div>

      {error && (
        <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800 rounded-xl mb-4">
          <p className="text-red-600 dark:text-red-400 text-sm text-center">{error}</p>
        </div>
      )}

      <p className="text-xs text-muted text-center">
        Paiement sécurisé par Mollie · CB, Apple Pay, Google Pay, iDEAL et plus
      </p>
    </div>
  )
}
