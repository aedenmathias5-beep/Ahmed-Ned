#!/bin/bash
# Script pour pousser les modifications sur GitHub
# Usage: ./push-to-github.sh

cd "/Users/aedenmathias/ahmed/Ahmed-Ned"

# Afficher le statut
echo "=== Statut actuel ==="
git log --oneline -3
git status

echo ""
echo "=== Configuration du remote avec token ==="
# Réinitialiser l'URL du remote (sans token dans l'URL visible)
git remote set-url origin https://github.com/aedenmathias5-beep/Ahmed-Ned.git

echo ""
echo "=== Préparation du push ==="
echo "Le système va demander vos identifiants GitHub."
echo "Username: aedenmathias5-beep"
echo "Password: [utilisez votre token: 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]"
echo ""

# Pousser avec demande interactive
git push origin main

echo ""
echo "=== Vérification ==="
git log --oneline -3
git status
